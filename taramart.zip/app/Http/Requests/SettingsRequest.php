<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SettingsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'app_name' => ['nullable', 'string', 'max:255'],
            'app_description' => ['nullable', 'string'],
            'items_per_page' => ['nullable', 'numeric', 'min:1', 'max:100'],
            'app_logo' => ['nullable', 'image', 'mimes:jpeg,png,jpg,gif,svg', 'max:2048'], 
            'theme' => ['nullable','string', 'max:255'],
            'currency' => ['nullable','string', 'max:255'],
            'google_map_location' => ['nullable','string'],


            'dc_inside' => ['nullable', 'numeric', 'min:1', 'max:500'],
            'dc_outside' => ['nullable', 'numeric', 'min:1', 'max:500'],
            
            // ✅ Contact settings validation
            'contact_phone' => ['nullable', 'string', 'max:50'],
            'contact_email' => ['nullable', 'email'],
            'contact_address' => ['nullable', 'string'],
            'business_hours' => ['nullable', 'string', 'max:100'],
            'support_email' => ['nullable', 'email'],

            // ✅ Social-media validation
            'facebook' => ['nullable', 'url'],
            'twitter' => ['nullable', 'url'],
            'linkedin' => ['nullable', 'url'],
            'instagram' => ['nullable', 'url'],
            'youtube' => ['nullable', 'url'],
            'tiktok' => ['nullable', 'url'],

            'attribute_system' => ['nullable', 'boolean'],

            // ✅ OTP validation
            'sms_notification' => ['nullable', 'boolean'],
            'sms_api_key' => 'nullable|string|max:255',
            'sms_api_url' => 'nullable|string|max:255', 
            'sms_sender_id' => 'nullable|string|max:255',   

            'email_notification' => ['nullable', 'boolean'],
           

            'selected_courier' => ['nullable', 'string', 'in:quirior,steedfast,available'],
            'steedfast_api_base_url' => ['nullable', 'url', 'max:255'],
            'steedfast_api_key' => ['nullable', 'string', 'max:255'],
            'steedfast_api_secret' => ['nullable', 'string', 'max:255'],
    
            'GOOGLE_CLIENT_SECRET' => ['nullable', 'string', 'max:255'],
            'GOOGLE_CLIENT_ID' => ['nullable', 'string', 'max:255'],
        ];
    }

    public function messages()
    {
        return [
            'app_name.string' => 'Application name must be a valid string.',
            'app_description.string' => 'Application description must be a valid string.',
            'items_per_page.numeric' => 'Items per page must be a numeric value.',

            'api_base_url.url' => 'The API Base URL must be a valid URL.',
            'api_key.string' => 'The API Key must be a valid string.',
            'api_secret.string' => 'The API Secret must be a valid string.',
            'api_available_queries.string' => 'Available Queries must be a valid string.',
        ];
    }
}
